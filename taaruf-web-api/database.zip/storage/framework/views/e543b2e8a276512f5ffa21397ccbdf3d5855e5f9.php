<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="<?php echo e(route('backend')); ?>"><?php echo config('app.name'); ?></a>
    </div>
    <ul class="sidebar-menu">
        <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>

  <div class="p-3 mt-2 mb-4">
    <a href="#" onclick="$('#logout-form').submit();" class="btn btn-danger btn-shadow btn-round has-icon has-icon-nofloat btn-block">
      <i class="ion ion-log-out"></i> <div>Keluar</div>
    </a>
  </div>
</aside>