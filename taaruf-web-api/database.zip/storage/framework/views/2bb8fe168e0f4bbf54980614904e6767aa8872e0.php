<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-4 offset-4">
            <div class="login-brand">
                <?php echo e(config('app.name')); ?>

            </div>

            <?php if($errors->has('email')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('email')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header"><h4>Reset Kata Sandi</h4></div>

                <div class="card-body">
                    <form method="post" action="<?php echo e(url('/password/reset')); ?>">
                        <?php echo csrf_field(); ?>


                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="form-group has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group has-feedback<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label>Kata Sandi Baru</label>
                            <input type="password" class="form-control" name="password">
                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group has-feedback<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label>Konfirmasi Kata Sandi</label>
                            <input type="password" name="password_confirmation" class="form-control">
                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>

                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-block btn-primary pull-right">
                                    <i class="fa fa-btn fa-refresh"></i>Reset Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Reset Kata Sandi'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>