<?php echo Form::open(['route' => ['backend.kotaTaarufs.destroy', $id], 'method' => 'delete']); ?>

<div class='btn-group'>
    <a href="<?php echo e(route('backend.kotaTaarufs.edit', $id)); ?>" class='btn btn-default btn-xs'>
        Edit
    </a>
    <?php echo Form::button('Delete', [
        'type' => 'submit',
        'class' => 'btn btn-danger btn-xs',
        'onclick' => "return confirm('Are you sure?')"
    ]); ?>

</div>
<?php echo Form::close(); ?>

