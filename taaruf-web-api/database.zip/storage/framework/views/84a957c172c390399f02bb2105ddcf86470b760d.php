<!-- Gender Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('gender', 'Gender:'); ?>

    <?php echo Form::text('gender', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- No Hp Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_hp', 'No Hp:'); ?>

    <?php echo Form::text('no_hp', null, ['class' => 'form-control']); ?>

</div>

<!-- Otp Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('otp_code', 'Otp Code:'); ?>

    <?php echo Form::number('otp_code', null, ['class' => 'form-control']); ?>

</div>

<!-- Verified Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('verified', 'Verified:'); ?>

    <?php echo Form::text('verified', null, ['class' => 'form-control']); ?>

</div>

<!-- Remember Token Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <?php echo Form::text('remember_token', null, ['class' => 'form-control']); ?>

</div>

<!-- Device Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('device_id', 'Device Id:'); ?>

    <?php echo Form::text('device_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('backend.appusers.index'); ?>" class="btn btn-default">Cancel</a>
</div>
