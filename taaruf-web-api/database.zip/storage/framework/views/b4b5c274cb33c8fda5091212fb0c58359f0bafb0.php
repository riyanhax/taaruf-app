<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Show Proposal</div>
        </h1>

        <div class="section-body">
            <div class="card">
                <div class="card-header"><h4>Show Proposal</h4></div>
                <div class="card-body">
                    <div class="row">
                        <?php echo $__env->make('backend.proposals.show_fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <a href="<?php echo route('backend.proposals.index'); ?>" class="btn btn-default">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Show Proposal'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>