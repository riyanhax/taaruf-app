<!-- Id Pengirim Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_pengirim', 'Id Pengirim:'); ?>

    <?php echo Form::number('id_pengirim', null, ['class' => 'form-control']); ?>

</div>

<!-- Id Penerima Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_penerima', 'Id Penerima:'); ?>

    <?php echo Form::number('id_penerima', null, ['class' => 'form-control']); ?>

</div>

<!-- Isi Proposal Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('isi_proposal', 'Isi Proposal:'); ?>

    <?php echo Form::textarea('isi_proposal', null, ['class' => 'form-control']); ?>

</div>

<!-- Readed Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('readed', 'Readed:'); ?>

    <?php echo Form::text('readed', null, ['class' => 'form-control']); ?>

</div>

<!-- Respon Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('respon', 'Respon:'); ?>

    <?php echo Form::text('respon', null, ['class' => 'form-control']); ?>

</div>

<!-- Balasan Penerima Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('balasan_penerima', 'Balasan Penerima:'); ?>

    <?php echo Form::textarea('balasan_penerima', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('backend.proposals.index'); ?>" class="btn btn-default">Cancel</a>
</div>
