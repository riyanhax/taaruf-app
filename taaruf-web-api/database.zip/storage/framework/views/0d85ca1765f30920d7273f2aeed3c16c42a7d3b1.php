<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<!-- Picture Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('picture', 'Picture:'); ?>

    <div class="input-group">
        <?php echo Form::text('picture', null, ['class' => 'form-control', 'id' => 'picture']); ?>

        <div class="input-group-append">
            <button type="button" class="btn btn-primary midia" data-input="picture">Pilih Gambar</button>
        </div>
    </div>
</div>

<!-- Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('content', 'Content:'); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control summernote']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('backend.blogs.index'); ?>" class="btn btn-default">Cancel</a>
</div>
