<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Edit Slider</div>
        </h1>
    
        <div class="section-body">
            <?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header"><h4>Edit Slider</h4></div>
                <div class="card-body">
                    <div class="row">
                         <?php echo Form::model($slider, ['route' => ['backend.sliders.update', $slider->id], 'method' => 'patch']); ?>


                            <?php echo $__env->make('backend.sliders.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Edit Slider'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>