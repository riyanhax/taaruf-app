

<?php

if($profile['foto'] != null){
    $fotopengirim = $profile['foto'];
    $location ='profile_pic';    
}else if($profile['foto'] == null && $appusers->gender == 'P' ){
    $fotopengirim = 'akhwat.png';
    $location ='media';
}else{
    $fotopengirim = 'ikhwan.png';
    $location ='media';
}
?>



<div class="col-md-6  col-lg-6 col-sm-12">
<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $appusers->id; ?></p>
</div>

<!-- Gender Field -->
<div class="form-group">
    <?php echo Form::label('gender', 'Gender:'); ?>

    <p><?php echo $appusers->gender; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $appusers->email; ?></p>
</div>

<!-- No Hp Field -->
<div class="form-group">
    <?php echo Form::label('no_hp', 'No Hp:'); ?>

    <p><?php echo $appusers->no_hp; ?></p>
</div>

<!-- Otp Code Field -->
<div class="form-group">
    <?php echo Form::label('otp_code', 'Otp Code:'); ?>

    <p><?php echo $appusers->otp_code; ?></p>
</div>

<!-- Verified Field -->
<div class="form-group">
    <?php echo Form::label('verified', 'Verified:'); ?>

    <p><?php echo $appusers->verified; ?></p>
</div>

<!-- Remember Token Field -->
<div class="form-group">
    <?php echo Form::label('remember_token', 'Remember Token:'); ?>

    <p><?php echo $appusers->remember_token; ?></p>
</div>

<!-- Device Id Field -->
<div class="form-group">
    <?php echo Form::label('device_id', 'Device Id:'); ?>

    <p><?php echo $appusers->device_id; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $appusers->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $appusers->updated_at; ?></p>
</div>

</div>



<div class="col-md-6 col-lg-6 col-sm-12" style="overflow:auto; height:100vh"> 
        <h6>Data Diri Pengirim</h6>
    <hr>


    <img style="margin:auto;width:150px;height:150px;" 
    src="<?php echo e(url('')); ?>/<?php echo e($location); ?>/<?php echo e($fotopengirim); ?>">
    <div class="form-group">
        <?php echo Form::label('nama_asli', 'Nama Asli:'); ?>

        <p><?php echo $profile['nama_asli']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('nama_samaran', 'Nama Samaran:'); ?>

        <p><?php echo $profile['nama_samaran']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('status_pernikahan', 'Status Pernikahan:'); ?>

        <p><?php echo $profile['status_pernikahan']; ?>, <?php if($profile['jumlah_anak']!= null ): ?> Anak <?php echo e($profile['jumlah_anak']['data_varchar']); ?> <?php endif; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tanggal_lahir', 'Tanggal Lahir:'); ?>

        <p><?php echo $profile['tanggal_lahir']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('hobby', 'Hobby:'); ?>

        <p><?php echo $profile['hobby']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('keahlian', 'Keahlian:'); ?>

        <p><?php echo $profile['keahlian']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('nomor_telp', 'Nomor Telp:'); ?>

        <p><?php echo $profile['nomor_telp']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tipe_tandapengenal', 'Tipe Tanda Pengenal:'); ?>

        <p><?php echo $profile['tipe_tandapengenal']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('nomor_tandapengenal', 'Nomor Tanda Pengenal:'); ?>

        <p><?php echo $profile['nomor_tandapengenal']; ?></p>
    </div>

    <br>
    <h6>Alamat KTP</h6>
    <hr>
    <div class="form-group">
        <?php echo Form::label('nama_jalan_ktp', 'Nama Jalan:'); ?>

        <p><?php echo $profile['nama_jalan_ktp']; ?></p>
    </div>
    <div class="form-group">
        <?php echo Form::label('ktp_rtrw', 'RT / RW:'); ?>

        <p><?php echo $profile['ktp_rtrw']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('ktp_kelurahan', 'Kelurahan:'); ?>

        <p><?php echo $profile['ktp_kelurahan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('ktp_kecamatan', 'Kecamatan:'); ?>

        <p><?php echo $profile['ktp_kecamatan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('ktp_kotakab', 'Kota / Kabupaten:'); ?>

        <p><?php echo $profile['ktp_kotakab']; ?></p>
    </div>
    <div class="form-group">
        <?php echo Form::label('ktp_provinsi', 'Provinsi:'); ?>

        <p><?php echo $profile['ktp_provinsi']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('ktp_kodepos', 'Kode Pos:'); ?>

        <p><?php echo $profile['ktp_kodepos']; ?></p>
    </div>
    <br>
    <h6>Alamat Tinggal</h6>
    <hr>
    <div class="form-group">
        <?php echo Form::label('tinggal_sda_ktp', 'Alamat Tinggal Sama Dengan KTP:'); ?>

        <p><?php echo $profile['tinggal_sda_ktp']; ?></p>
    </div>
    <?php if( $profile['tinggal_sda_ktp']!= 'sama'): ?>
    <div class="form-group">
        <?php echo Form::label('tinggal_nama_jalan', 'Nama Jalan:'); ?>

        <p><?php echo $profile['tinggal_nama_jalan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tinggal_rtrw', 'RT / RW:'); ?>

        <p><?php echo $profile['tinggal_rtrw']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tinggal_kelurahan', 'Kelurahan:'); ?>

        <p><?php echo $profile['tinggal_kelurahan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tinggal_kecamatan', 'Kecamatan:'); ?>

        <p><?php echo $profile['tinggal_kecamatan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tinggal_kotakab', 'Kota / Kabupaten:'); ?>

        <p><?php echo $profile['tinggal_kotakab']; ?></p>
    </div>
    <div class="form-group">
        <?php echo Form::label('tinggal_provinsi', 'Provinsi:'); ?>

        <p><?php echo $profile['tinggal_provinsi']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('tinggal_kodepos', 'Kode Pos:'); ?>

        <p><?php echo $profile['tinggal_kodepos']; ?></p>
    </div>

    <?php endif; ?>
    <br>
    <h6>Pendidikan</h6>
    <hr>
    <?php if($profile['pend_sd']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_sd', 'SD:'); ?>

        <p><?php echo $profile['pend_sd']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_smp']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_smp', 'SMP:'); ?>

        <p><?php echo $profile['pend_smp']; ?></p>
    </div>

    <?php if($profile['pend_slta']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_slta', 'SLTA:'); ?>

        <p><?php echo $profile['pend_slta']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_diploma']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_diploma', 'Diploma:'); ?>

        <p><?php echo $profile['pend_diploma']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_s1']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_s1', 'S1:'); ?>

        <p><?php echo $profile['pend_s1']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_s2']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_s2', 'S2:'); ?>

        <p><?php echo $profile['pend_s2']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_s3']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_s3', 'S3:'); ?>

        <p><?php echo $profile['pend_s3']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_lain']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_lain', 'Lain-lain:'); ?>

        <p><?php echo $profile['pend_lain']; ?></p>
    </div>
    <?php endif; ?>

    <?php if($profile['pend_nonformal']!= null): ?>
    <div class="form-group">
        <?php echo Form::label('pend_nonformal', 'Non-formal:'); ?>

        <p><?php echo $profile['pend_nonformal']; ?></p>
    </div>
    <?php endif; ?>

    <br>
    <h6>Pekerjaan</h6>
    <hr>

    
    <div class="form-group">
        <?php echo Form::label('nama_pekerjaan', 'Nama Pekerjaan:'); ?>

        <p><?php echo $profile['nama_pekerjaan']; ?></p>
    </div>
    <?php endif; ?>

    <div class="form-group">
        <?php echo Form::label('tipe_pekerjaan', 'Tipe Pekerjaan:'); ?>

        <p><?php echo $profile['tipe_pekerjaan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('golongan_pekerjaan', 'Golongan Pekerjaan:'); ?>

        <p><?php echo $profile['golongan_pekerjaan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('penghasilan_pekerjaan', 'Penghasilan perbulan:'); ?>

        <p><?php echo $profile['penghasilan_pekerjaan']; ?></p>
    </div>

    <br>
    <h6>Fisik</h6>
    <hr>

    <div class="form-group">
        <?php echo Form::label('tinggi_badan', 'Tinggi Badan:'); ?>

        <p><?php echo $profile['tinggi_badan']; ?> cm</p>
    </div>

    <div class="form-group">
        <?php echo Form::label('berat_badan', 'Berat Badan:'); ?>

        <p><?php echo $profile['berat_badan']; ?> Kg</p>
    </div>

    <div class="form-group">
        <?php echo Form::label('warna_kulit', 'Warna Kulit:'); ?>

        <p><?php echo $profile['warna_kulit']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('penilaian_wajah', 'Penilaian Wajah:'); ?>

        <p><?php echo $profile['penilaian_wajah']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('riwayat_penyakit', 'Riwayat Penyakit:'); ?>

        <p><?php echo $profile['riwayat_penyakit']; ?></p>
    </div>

    <br>
    <h6>Keluarga</h6>
    <hr>

    <div class="form-group">
        <?php echo Form::label('tinggal_bersama', 'Tinggal bersama:'); ?>

        <p><?php echo $profile['tinggal_bersama']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('pekerjaan_ayah', 'Pekerjaan Ayah:'); ?>

        <p><?php echo $profile['pekerjaan_ayah']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('pekerjaan_ibu', 'Pekerjaan Ibu:'); ?>

        <p><?php echo $profile['pekerjaan_ibu']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('anak_ke', 'Anak ke:'); ?>

        <p><?php echo $profile['anak_ke']; ?> dari 
            <?php echo $profile['jumlah_saudara']; ?> Bersaudara
        </p>
    </div>

    <div class="form-group">
        <?php echo Form::label('jum_kakak', 'Jumlah kakak:'); ?>

        <p>Total <?php echo $profile['jum_kakak']; ?>, 
            <?php echo $profile['jum_kakak_laki']; ?> Lk, <?php echo $profile['jum_kakak_perem']; ?> Pr

        </p>
    </div>

    <div class="form-group">
        <?php echo Form::label('jum_adik', 'Jumlah Adik:'); ?>

        <p>Total<?php echo $profile['jum_adik']; ?>, 
            <?php echo $profile['jum_adik_laki']; ?> Lk, <?php echo $profile['jum_adik_perem']; ?> Pr
        </p>
    </div>

    <br>
    <h6>Keislaman</h6>
    <hr>

        <div class="form-group">
        <?php echo Form::label('apakah_ikut_kajian_rutin', 'Apakah ikut kajian rutin:'); ?>

        <p><?php echo $profile['apakah_ikut_kajian_rutin']; ?></p>
    </div>

        <div class="form-group">
        <?php echo Form::label('solat_5_waktu', 'Sholat 5 Waktu:'); ?>

        <p><?php echo $profile['solat_5_waktu']; ?></p>
    </div>

        <div class="form-group">
        <?php echo Form::label('membaca_alquran', 'Membaca Alquran:'); ?>

        <p><?php echo $profile['membaca_alquran']; ?></p>
    </div>


    <div class="form-group">
        <?php echo Form::label('sholat_sunnah', 'Sholat Sunnah:'); ?>

        <p><?php echo $profile['sholat_sunnah']; ?></p>
    </div>


    <div class="form-group">
        <?php echo Form::label('puasa_sunnah', 'Puasa Sunnah:'); ?>

        <p><?php echo $profile['puasa_sunnah']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('afiliasi_keagamaan', 'Afilasi Keagamaan:'); ?>

        <p><?php echo $profile['afiliasi_keagamaan']; ?></p>
    </div>
    <?php if(isset($profile['min_usia']['data_integer'])): ?>
    <br>
    <h6>Kriteria yang dicari</h6>
    <hr>

    <div class="form-group">
        <?php echo Form::label('usia', 'Usia:'); ?>

        <p><?php echo $profile['min_usia']; ?> - <?php echo $profile['max_usia']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('berat', 'Berat:'); ?>

        <p><?php echo $profile['min_berat']; ?> - <?php echo $profile['max_berat']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('kriteria_afiliasi_keagamaan', 'Afilasi Keagamaan:'); ?>

        <p><?php echo $profile['kriteria_afiliasi_keagamaan']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('pendidikan_minimal', 'Afilasi Keagamaan:'); ?>

        <p><?php echo $profile['pendidikan_minimal']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('kriteria_status', 'Afilasi Keagamaan:'); ?>

        <p><?php echo $profile['kriteria_status']; ?></p>
    </div>

    <div class="form-group">
        <?php echo Form::label('minimum_penghasilan', 'Minimum Penghasilan:'); ?>

        <p><?php echo $profile['minimum_penghasilan']; ?></p>
    </div>

    <?php endif; ?>

    












</div>

