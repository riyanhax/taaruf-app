<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Appusers</div>
            <div class="float-right">
               <a class="btn btn-primary btn-sm" href="<?php echo route('backend.appusers.create'); ?>">Add New</a>
           </div>
        </h1>
    
        <div class="section-body">
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header"><h4>Appusers</h4></div>
                <div class="card-body">
                    <?php echo $__env->make('backend.appusers.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="card-footer">
                    <div class="text-center">
                    
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['title' => 'Appusers'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>