<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-4 offset-4">
            <div class="card pl-3 pr-3 pb-3">
                <div class="login-brand">
                    <a href="<?php echo e(url('/home')); ?>"><b><?php echo e(config('app.name')); ?></b></a>
                </div>

                <!-- /.login-logo -->
                <div class="login-box-body">
                    <p class="login-box-msg">Enter Email to reset password</p>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(url('/password/email')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="form-group has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right">
                                    <i class="fa fa-btn fa-envelope"></i> Send Password Reset Link
                                </button>
                            </div>
                        </div>

                    </form>

                </div>
                <!-- /.login-box-body -->
            </div>
        </div>
    </div>
</div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Login'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>