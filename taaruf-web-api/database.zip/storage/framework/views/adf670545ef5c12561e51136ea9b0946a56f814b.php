<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Users</div>
            <div class="float-right">
               <a class="btn btn-primary btn-sm" href="<?php echo route('register'); ?>">Register New User</a>
           </div>
        </h1>
    
        <div class="section-body">
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header"><h4>Users</h4></div>
                <div class="card-body">
                    <?php echo $__env->make('backend.users.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="card-footer">
                    <div class="text-center">
                    
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['title' => 'Users'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>