<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Link Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('link', 'Link:'); ?>

    <?php echo Form::text('link', null, ['class' => 'form-control']); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <div class="input-group">
        <?php echo Form::text('image', null, ['class' => 'form-control', 'id' => 'image']); ?>

        <div class="input-group-append">
            <button type="button" class="btn btn-primary midia" data-input="image">Pilih Gambar</button>
        </div>
    </div>
</div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::select('status', ['active' => 'Active', 'notactive' => 'Not Active'], null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('backend.banners.index'); ?>" class="btn btn-default">Cancel</a>
</div>
