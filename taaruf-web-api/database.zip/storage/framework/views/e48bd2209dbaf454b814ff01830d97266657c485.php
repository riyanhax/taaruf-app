<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-4 offset-4">
            <div class="login-brand">
                <?php echo e(config('app.name')); ?>

            </div>

            <?php if($errors->has('email')): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('email')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header"><h4>Login</h4></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>" class="needs-validation" novalidate="">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="email">Alamat Email</label>

                            <input id="email" type="email" class="form-control" name="email" tabindex="1" value="<?php echo e(old('email')); ?>" required autofocus>
                            <div class="invalid-feedback">
                                Harap isi email Anda
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="d-block">Kata Sandi
                            </label>

                            <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                            <div class="invalid-feedback">
                                Harap isi kata sandi Anda
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="custom-control custom-checkbox float-left">
                                <input type="checkbox" name="remember" class="custom-control-input" <?php echo e(old('remember') ? 'checked' : ''); ?> tabindex="3" id="remember-me">
                                <label class="custom-control-label" for="remember-me">Remember Me</label>
                            </div>
                            <div class="float-right">
                                <a href="<?php echo e(url('/password/reset')); ?>">Lupa Kata Sandi?</a>
                            </div>
                        </div>

                        

                        <div class="form-group mt-5">
                            <button type="submit" class="btn btn-primary btn-block" tabindex="4">
                                Login
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="simple-footer">
                Copyright &copy; <?php echo e(config('app.name')); ?> <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Login'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>