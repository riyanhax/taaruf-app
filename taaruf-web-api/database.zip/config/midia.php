<?php
return [
	// Target diirectory
	'directory' => storage_path('app/public/media'),
	// For URL (e.g: http://base/media/filename.ext)
	'directory_name' => 'media',
	'prefix' => 'midia',
	// Thumb
	'thumbs' => [100],
];